<!-- Cloud mask polygon GML for T34UEC cloud_cov=75.0% -->
<gml:FeatureCollection></gml:FeatureCollection>
