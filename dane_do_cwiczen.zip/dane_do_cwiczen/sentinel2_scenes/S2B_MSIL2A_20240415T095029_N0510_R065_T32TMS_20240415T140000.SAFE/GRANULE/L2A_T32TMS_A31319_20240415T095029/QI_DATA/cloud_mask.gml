<!-- Cloud mask polygon GML for T32TMS cloud_cov=5.4% -->
<gml:FeatureCollection></gml:FeatureCollection>
