<!-- Cloud mask polygon GML for T33UXT cloud_cov=18.2% -->
<gml:FeatureCollection></gml:FeatureCollection>
