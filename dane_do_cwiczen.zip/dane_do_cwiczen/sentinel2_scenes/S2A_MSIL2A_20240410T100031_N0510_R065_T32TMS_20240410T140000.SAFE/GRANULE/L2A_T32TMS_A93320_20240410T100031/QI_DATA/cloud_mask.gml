<!-- Cloud mask polygon GML for T32TMS cloud_cov=18.2% -->
<gml:FeatureCollection></gml:FeatureCollection>
