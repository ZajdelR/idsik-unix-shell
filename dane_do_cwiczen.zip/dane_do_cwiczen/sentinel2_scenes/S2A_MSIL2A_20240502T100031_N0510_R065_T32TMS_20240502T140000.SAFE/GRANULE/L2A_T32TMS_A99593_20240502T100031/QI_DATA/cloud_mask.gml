<!-- Cloud mask polygon GML for T32TMS cloud_cov=8.9% -->
<gml:FeatureCollection></gml:FeatureCollection>
