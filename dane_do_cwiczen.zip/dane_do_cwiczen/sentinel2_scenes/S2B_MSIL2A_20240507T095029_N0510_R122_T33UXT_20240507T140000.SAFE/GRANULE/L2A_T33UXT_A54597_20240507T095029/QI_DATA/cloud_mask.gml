<!-- Cloud mask polygon GML for T33UXT cloud_cov=2.1% -->
<gml:FeatureCollection></gml:FeatureCollection>
