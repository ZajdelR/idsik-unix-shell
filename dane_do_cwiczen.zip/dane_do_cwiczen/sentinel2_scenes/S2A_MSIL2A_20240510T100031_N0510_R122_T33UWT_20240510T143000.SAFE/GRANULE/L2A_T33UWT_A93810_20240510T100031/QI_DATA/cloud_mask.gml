<!-- Cloud mask polygon GML for T33UWT cloud_cov=12.4% -->
<gml:FeatureCollection>
</gml:FeatureCollection>
