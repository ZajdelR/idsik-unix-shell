#!/usr/bin/env bash

# Skrypt: filter_clouds.sh
# Opis: Filtruje raport zachmurzenia według zadanego kafelka MGRS i maksymalnego dopuszczalnego zachmurzenia.
# Użycie: bash filter_clouds.sh <plik_raportu.csv> <kafelek_MGRS> <max_cloud_percent>

REPORT="$1"
TILE="$2"
MAX_CLOUD="$3"

echo "Filtrowanie scen dla kafelka: $TILE w pliku $REPORT (Max zachmurzenie: ${MAX_CLOUD}%)"
grep "$TILE" "$REPORT" | awk -F',' -v max="$MAX_CLOUD" '$6 <= max {print $1, "Data:", $2, "Zachmurzenie:", $6"%"}'
