<!-- Cloud mask polygon GML for T34UCA cloud_cov=15.3% -->
<gml:FeatureCollection>
</gml:FeatureCollection>
