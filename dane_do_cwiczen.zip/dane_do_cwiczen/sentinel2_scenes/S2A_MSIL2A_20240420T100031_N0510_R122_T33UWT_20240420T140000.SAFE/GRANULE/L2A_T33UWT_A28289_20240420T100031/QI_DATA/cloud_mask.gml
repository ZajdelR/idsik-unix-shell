<!-- Cloud mask polygon GML for T33UWT cloud_cov=75.0% -->
<gml:FeatureCollection></gml:FeatureCollection>
