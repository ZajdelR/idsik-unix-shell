<!-- Cloud mask polygon GML for T33UWT cloud_cov=3.1% -->
<gml:FeatureCollection>
</gml:FeatureCollection>
