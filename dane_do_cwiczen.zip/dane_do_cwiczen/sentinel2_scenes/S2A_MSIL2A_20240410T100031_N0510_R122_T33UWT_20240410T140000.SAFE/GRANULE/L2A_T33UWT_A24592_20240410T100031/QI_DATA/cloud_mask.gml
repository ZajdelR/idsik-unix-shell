<!-- Cloud mask polygon GML for T33UWT cloud_cov=18.2% -->
<gml:FeatureCollection></gml:FeatureCollection>
