<!-- Cloud mask polygon GML for T33UWS cloud_cov=75.0% -->
<gml:FeatureCollection></gml:FeatureCollection>
