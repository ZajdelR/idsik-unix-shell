================================================================================
ROZSZERZONY PAKIET DANYCH: INŻYNIERIA DANYCH SATELITARNYCH I KOSMICZNYCH
Zarządzanie projektem informatycznym (UPWr 2026/2027)
================================================================================

Ten zestaw danych zawiera tysiące plików i struktur katalogowych symulujących
rzeczywiste środowisko pracy inżyniera danych satelitarnych w centrach przetwarzania
danych (np. ESA CDS, USGS, EUMETSAT, Copernicus Data Space Ecosystem).

Struktura katalogów i zawartość:

1. sentinel2_scenes/
   Struktury produktów Sentinel-2 L2A (.SAFE) dla kafelków w Polsce i Europie
   (Wrocław T33UWT, Warszawa T34UCA, Poznań T33UXT, Kraków T34UDE, Gdańsk T34UEC,
   Alpy T32TMS). Zawierają pliki metadanych MTD_MSIL2A.xml, manifest.safe, kanały
   spektralne 10m i 20m oraz raporty jakości QI_DATA.

2. landsat_scenes/
   Struktury produktów Landsat-8/9 Collection 2 Level-2 (L2SP) z plikami metadanych
   MTL.txt, raportami kątowymi ANG.txt oraz rastrami pasm spektralnych (SR_B1..B7, QA_PIXEL).

3. telemetry_logs/
   Setki dobowych dzienników stacji naziemnych (Spitsbergen, Kiruna, Maspalomas,
   Kourou, Troll, Matera, Inuvik, Punta Arenas) z lat 2023-2024 oraz skompresowane
   miesięczne archiwa .log.gz.

4. cloud_cover_reports/
   Tabelaryczne bazy danych CSV z dziesiątkami tysięcy rekordów obserwacji
   satelitarnych (pokrycie chmurami, śniegiem, kąty słoneczne, flagi jakości).

5. orbital_catalog/
   Katalogi parametrów orbitalnych (TLE) ponad 80 aktywnych satelitów obserwacji Ziemi,
   specyfikacje techniczne sensorów (MSI, OLI, TIRS, SAR C-band, OLCI) oraz harmonogramy
   przelotów.

6. gnss_stations/
   Dobowe logi jakości i skompresowane pliki obserwacyjne RINEX dla 15 europejskich
   stacji referencyjnych sieci ASG-EUPOS oraz EPN (m.in. WROC, JOZE, KRAK, GDAN, POZN).

7. raw_telemetry_chunks/
   Tysiące surowych pakietów telemetrycznych (chunk_*.dat / chunk_*.log)
   do testowania wydajności potoków powłoki Bash, poleceń find, xargs, cat i zliczania.

8. scripts_repo/
   Szablony skryptów powłoki Bash do automatyzacji przetwarzania danych i kontroli jakości.
================================================================================
