<!-- Cloud mask polygon GML for T33UWS cloud_cov=8.9% -->
<gml:FeatureCollection></gml:FeatureCollection>
