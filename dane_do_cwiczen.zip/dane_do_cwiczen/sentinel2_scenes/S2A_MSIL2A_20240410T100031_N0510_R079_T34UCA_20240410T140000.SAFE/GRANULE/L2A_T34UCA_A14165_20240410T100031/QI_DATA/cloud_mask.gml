<!-- Cloud mask polygon GML for T34UCA cloud_cov=18.2% -->
<gml:FeatureCollection></gml:FeatureCollection>
