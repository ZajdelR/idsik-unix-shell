<!-- Cloud mask polygon GML for T34UEC cloud_cov=5.4% -->
<gml:FeatureCollection></gml:FeatureCollection>
