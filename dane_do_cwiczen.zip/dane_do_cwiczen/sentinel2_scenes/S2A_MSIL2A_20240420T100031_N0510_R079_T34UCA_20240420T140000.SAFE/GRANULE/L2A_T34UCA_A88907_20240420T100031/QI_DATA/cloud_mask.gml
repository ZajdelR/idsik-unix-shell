<!-- Cloud mask polygon GML for T34UCA cloud_cov=75.0% -->
<gml:FeatureCollection></gml:FeatureCollection>
