<!-- Cloud mask polygon GML for T33UWS cloud_cov=18.2% -->
<gml:FeatureCollection></gml:FeatureCollection>
