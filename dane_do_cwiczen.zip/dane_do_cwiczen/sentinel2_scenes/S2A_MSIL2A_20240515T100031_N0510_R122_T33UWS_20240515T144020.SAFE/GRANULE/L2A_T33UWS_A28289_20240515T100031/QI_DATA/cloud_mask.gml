<!-- Cloud mask polygon GML for T33UWS cloud_cov=48.9% -->
<gml:FeatureCollection>
</gml:FeatureCollection>
