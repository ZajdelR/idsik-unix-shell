<!-- Cloud mask polygon GML for T33UWS cloud_cov=2.1% -->
<gml:FeatureCollection></gml:FeatureCollection>
