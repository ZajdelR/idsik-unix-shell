<!-- Cloud mask polygon GML for T34UCA cloud_cov=5.4% -->
<gml:FeatureCollection></gml:FeatureCollection>
