<!-- Cloud mask polygon GML for T33UWT cloud_cov=8.9% -->
<gml:FeatureCollection></gml:FeatureCollection>
