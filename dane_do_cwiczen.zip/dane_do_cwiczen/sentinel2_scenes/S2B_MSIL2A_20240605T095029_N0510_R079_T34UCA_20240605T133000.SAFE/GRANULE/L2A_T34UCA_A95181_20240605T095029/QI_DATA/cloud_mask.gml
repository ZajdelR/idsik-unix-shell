<!-- Cloud mask polygon GML for T34UCA cloud_cov=91.5% -->
<gml:FeatureCollection>
</gml:FeatureCollection>
