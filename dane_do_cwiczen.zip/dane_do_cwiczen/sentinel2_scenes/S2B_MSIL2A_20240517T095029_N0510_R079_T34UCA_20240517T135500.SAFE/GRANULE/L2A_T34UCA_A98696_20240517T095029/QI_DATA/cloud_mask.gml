<!-- Cloud mask polygon GML for T34UCA cloud_cov=0.8% -->
<gml:FeatureCollection>
</gml:FeatureCollection>
