<!-- Cloud mask polygon GML for T33UWS cloud_cov=5.4% -->
<gml:FeatureCollection></gml:FeatureCollection>
