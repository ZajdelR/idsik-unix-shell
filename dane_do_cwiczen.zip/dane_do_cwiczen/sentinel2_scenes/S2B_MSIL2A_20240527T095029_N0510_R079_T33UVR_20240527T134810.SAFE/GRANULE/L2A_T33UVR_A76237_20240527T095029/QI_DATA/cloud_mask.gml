<!-- Cloud mask polygon GML for T33UVR cloud_cov=22.0% -->
<gml:FeatureCollection>
</gml:FeatureCollection>
