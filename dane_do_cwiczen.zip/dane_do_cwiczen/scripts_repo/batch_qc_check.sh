#!/usr/bin/env bash

# Skrypt: batch_qc_check.sh
# Opis: Wyszukuje wszystkie uszkodzone pakiety w surowych strumieniach danych telemetrycznych.
# Użycie: bash batch_qc_check.sh

echo "=== Rozpoczecie kontroli jakosci (QC) strumieni telemetrycznych ==="
total_chunks=$(ls raw_telemetry_chunks/*.dat | wc -l)
total_errors=$(grep -c "CRC_ERR" raw_telemetry_chunks/*.dat 2>/dev/null | grep -v ":0$" | wc -l)

echo "Przeanalizowano plikow chunk: $total_chunks"
echo "Liczba plikow zawierajacych bledy CRC: $total_errors"
