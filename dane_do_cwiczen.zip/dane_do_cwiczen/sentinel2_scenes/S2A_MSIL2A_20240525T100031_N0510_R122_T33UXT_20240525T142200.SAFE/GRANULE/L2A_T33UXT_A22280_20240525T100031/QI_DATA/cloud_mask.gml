<!-- Cloud mask polygon GML for T33UXT cloud_cov=6.7% -->
<gml:FeatureCollection>
</gml:FeatureCollection>
