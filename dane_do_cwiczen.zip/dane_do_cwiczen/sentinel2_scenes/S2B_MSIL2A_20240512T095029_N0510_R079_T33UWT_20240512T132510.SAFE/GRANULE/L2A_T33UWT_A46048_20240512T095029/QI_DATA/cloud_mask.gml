<!-- Cloud mask polygon GML for T33UWT cloud_cov=4.2% -->
<gml:FeatureCollection>
</gml:FeatureCollection>
