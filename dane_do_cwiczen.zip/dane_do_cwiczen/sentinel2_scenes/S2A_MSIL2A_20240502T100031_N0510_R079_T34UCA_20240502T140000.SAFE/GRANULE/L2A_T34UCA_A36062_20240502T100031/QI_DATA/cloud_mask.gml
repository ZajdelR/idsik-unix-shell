<!-- Cloud mask polygon GML for T34UCA cloud_cov=8.9% -->
<gml:FeatureCollection></gml:FeatureCollection>
