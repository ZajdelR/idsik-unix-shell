#!/usr/bin/env bash

# Skrypt: count_telemetry_errors.sh
# Opis: Zlicza błędy w logach wybranej stacji naziemnej.
# Użycie: bash count_telemetry_errors.sh <kod_stacji_np_SVB>

STATION="$1"
echo "Analiza błędów telemetrycznych dla stacji: $STATION"

grep "ERROR" telemetry_logs/ground_station_${STATION}_*.log 2>/dev/null | wc -l
