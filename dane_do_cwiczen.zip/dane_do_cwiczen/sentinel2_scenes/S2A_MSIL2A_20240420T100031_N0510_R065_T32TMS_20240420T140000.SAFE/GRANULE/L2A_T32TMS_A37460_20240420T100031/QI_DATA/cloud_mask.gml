<!-- Cloud mask polygon GML for T32TMS cloud_cov=75.0% -->
<gml:FeatureCollection></gml:FeatureCollection>
